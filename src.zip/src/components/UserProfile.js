import React, { Component } from "react";
import {
  Text,
  TouchableWithoutFeedback,
  TouchableOpacity,
  View,
  LayoutAnimation,
  UIManager,
  Image,
  TextInput,
  ScrollView,
  ListView,
  Alert
} from "react-native";
import _ from 'lodash';
import { Actions } from 'react-native-router-flux';
import { connect } from "react-redux";
import { CardSection, Card, Button } from "./common";
import { UserFetchInfo } from '../actions';


class UserProfile extends Component {

        componentWillMount() {
          this.props.UserFetchInfo();
            this.createDataSource(this.props);
          }

          componentWillReceiveProps(nextProps) {
            // nextProps are the next set of props that this component
            // will be rendered with
            // this.props is still the old set of props

            this.createDataSource(nextProps);
          }

          createDataSource({ Info }) {
            const ds = new ListView.DataSource({
              rowHasChanged: (r1, r2) => r1 !== r2
            });

            this.dataSource = ds.cloneWithRows(Info);
        }

    renderRow(Info) {
      console.log('this.props');
      console.log(this.props.em);
      console.log('this.props');
if (this.props.em || this.props.emlog ) {
        return (

          <Card style={{ flex: 1 }}>
            <CardSection>
              <Text style={{ paddingRight: 5 }}> {Info.email} </Text>
            </CardSection>
        </Card>

      );
} else
{
  Alert.alert(
    'تنبيه',
    'يجب عليك التسجيل اولا',
    [
      {text: 'التسجيل', onPress: () => Actions.Auth() },
      {text: 'الغاء', style: 'cancel'}
    ],
    { cancelable: false }
  )
  return (
  <Card style={{ flex: 1 }}>
  <CardSection>
  <Text style={{ alignSelf: "center",
  color: "red",
  fontSize: 16,
  fontWeight: "600",
  paddingTop: 10,
  paddingBottom: 10,
  }}>
  انت غير مسجل ، يجب عليك التسجيل اولا
  </Text>
  </CardSection>

    <CardSection>
    <TouchableOpacity
      style={{flex: 1,
      alignSelf: 'stretch',
      backgroundColor: '#fff',
      borderRadius: 5,
      borderWidth: 1,
      borderColor: '#007aff',
      marginLeft: 5,
      marginRight: 5}}
      onPress={() => Actions.Auth()}

    >
      <Text style={{ alignSelf: "center",
      color: "#007aff",
      fontSize: 16,
      fontWeight: "600",
      paddingTop: 10,
      paddingBottom: 10}}>
للتسجيل اضغط هنا
      </Text>
    </TouchableOpacity>
    </CardSection>
</Card>
)};
    }
      render() {
                return (

                  this.props.Info.map((Info) => {
                    return (
                    this.renderRow(Info));
                  })
                );
          }
}

const MapStateTpProps = state => {
  const em = state.auth.email;
  const emlog = state.auth.emaillog;
  const language = state.language.Language;

  const Info = _.map(state.userInfo, (val, uid) => {
    return { ...val, uid };
});
  return { Info, em, emlog, language };
};


export default connect(MapStateTpProps, { UserFetchInfo })(UserProfile);
