export const arabicLanguage = () => {
  return {
    type: 'ARABIC_LANGUAGE'
  };
};

export const englishLanguage = () => {
  return {
    type: 'ENGLISH_LANGUAGE'
  };
};
